package com.bitmap.szlizb.recycleviewdemo;

/**
 * Created by szlizb on 2016/6/21.
 */

public class Item {

    public int imgId;
    public String desc;

    public Item(String desc, int imgId) {
        this.desc = desc;
        this.imgId = imgId;
    }
}
